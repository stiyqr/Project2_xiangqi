#pragma once

#include "imgui/imgui.h"
#include "imgui/imgui_impl_dx9.h"
#include "imgui/imgui_impl_win32.h"

#define IMGUI_DEFINE_MATH_OPERATORS

#include "imgui/imgui_internal.h"
#include <d3dx9.h>
#pragma comment (lib, "d3dx9.lib")
#include <d3d9.h>
#pragma comment (lib,"d3d9.lib")