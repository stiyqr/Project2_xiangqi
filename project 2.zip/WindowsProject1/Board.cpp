#include "Board.h"

// Static declaration
float Board::xPosition[9] = { 180, 233.75, 287.5, 341.25, 395, 448.75, 502.5, 556.25, 610 };
float Board::yPosition[10] = { 55, 100, 145, 190, 235, 280, 325, 370, 415, 460 };