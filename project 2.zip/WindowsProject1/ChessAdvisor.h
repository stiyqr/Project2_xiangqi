#pragma once
#include "Chess.h"

class ChessAdvisor : public Chess {
public:
	ChessAdvisor();
	ChessAdvisor(const char*, int, int);

	void updateAllPossibleMove(std::vector<Chess*>) override;
};