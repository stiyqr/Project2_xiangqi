#pragma once

#include "ChessAdvisor.h"
#include "ChessCannon.h"
#include "ChessChariot.h"
#include "ChessElephant.h"
#include "ChessGeneral.h"
#include "ChessHorse.h"
#include "ChessSoldier.h"