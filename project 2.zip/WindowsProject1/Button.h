#pragma once
#include "imgui/imgui.h"
#include <iostream>

class Button {
private:
	bool isClicked;
public:
	enum class Type{MAINMENU, CIRCLE};
	Type buttonType;

	// Constructor
	Button();
	Button(const char* name, Type type);
	~Button();

	operator bool()const;
};