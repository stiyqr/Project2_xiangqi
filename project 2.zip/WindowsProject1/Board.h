#pragma once

class Board {
public:
	static float xPosition[9];
	static float yPosition[10];
};